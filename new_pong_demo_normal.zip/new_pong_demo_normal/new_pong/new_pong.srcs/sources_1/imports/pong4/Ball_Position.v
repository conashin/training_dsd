module Ball_Position
#(
    parameter pos_MAX     = 11'd0,
    parameter pos_MIN     = 11'd0,
    parameter origin      = 11'd0,
    parameter Ball_Speed  = 32'd0
)
(
    input           i_Clock,
    input           i_Reset,
    input           i_Paddle_Hit,
    input           i_Win,
    input           i_Space,
    output          o_Direction,
    output [10:0]   o_Pos
);

    reg [31:0] r_Count;
    reg [31:0] r_Count_Inv;
    reg [10:0] r_Pos;
    reg        r_Direction;
    reg [1:0]  r_state, next_state;

    localparam IDLE = 2'b01;
    localparam PLAY = 2'b10;

    // === ²�� LFSR�]4-bit�^�Ω��H���o�y��V ===
    reg [3:0] rand_reg = 4'b1011;
    wire feedback = rand_reg[3] ^ rand_reg[2];

    always @(posedge i_Clock) begin
        rand_reg <= {rand_reg[2:0], feedback};
    end

    // === Space Enable ����]�ݩ�}�A���^ ===
    reg space_enable = 1'b1;

    always @(posedge i_Clock) begin
        if (i_Reset || i_Win)
            space_enable <= 1'b1;
        else if (~i_Space)
            space_enable <= 1'b1;
        else if (i_Space && space_enable)
            space_enable <= 1'b0;
    end

    // === ���A�ಾ ===
    always @(posedge i_Clock) begin
        if(i_Reset)
            r_state <= IDLE;
        else
            r_state <= next_state;
    end

    // === �D�޿� ===
    always @(posedge i_Clock) begin
        next_state <= r_state;

        case(r_state)
            IDLE: begin
                r_Pos <= origin;
                r_Count <= 0;
                r_Count_Inv <= 0;
                r_Direction <= rand_reg[0];  // �� �ϥ� LFSR �M�w��V
                if (i_Space && space_enable) begin
                    r_Direction <= rand_reg[0];  // �� �o�y���@�����M�w��V
                    next_state <= PLAY;
                end
                else
                    next_state <= IDLE;
            end

            PLAY: begin
                if (i_Reset || i_Win) begin
                    r_Pos <= origin;
                    r_Count <= 0;
                    r_Count_Inv <= 0;
                    r_Direction <= rand_reg[0];  // �i���ݨD�O���o��
                    next_state <= IDLE;
                end else begin
                    next_state <= PLAY;

                    if (i_Paddle_Hit) begin
                        r_Direction <= ~r_Direction;
                        if (r_Direction)
                            r_Pos <= (r_Pos > pos_MIN) ? r_Pos - 1 : r_Pos;
                        else
                            r_Pos <= (r_Pos < pos_MAX) ? r_Pos + 1 : r_Pos;

                        r_Count <= 0;
                        r_Count_Inv <= 0;
                    end else begin
                        if (r_Direction) begin
                            if (r_Count == Ball_Speed) begin
                                r_Count <= 0;
                                if (r_Pos < pos_MAX)
                                    r_Pos <= r_Pos + 1;
                                else begin
                                    r_Direction <= 1'b0;
                                    r_Pos <= r_Pos - 1;
                                end
                            end else
                                r_Count <= r_Count + 1;
                        end else begin
                            if (r_Count_Inv == Ball_Speed) begin
                                r_Count_Inv <= 0;
                                if (r_Pos > pos_MIN)
                                    r_Pos <= r_Pos - 1;
                                else begin
                                    r_Direction <= 1'b1;
                                    r_Pos <= r_Pos + 1;
                                end
                            end else
                                r_Count_Inv <= r_Count_Inv + 1;
                        end
                    end
                end
            end

            default: next_state <= IDLE;
        endcase
    end

    assign o_Pos = r_Pos;
    assign o_Direction = r_Direction;

endmodule