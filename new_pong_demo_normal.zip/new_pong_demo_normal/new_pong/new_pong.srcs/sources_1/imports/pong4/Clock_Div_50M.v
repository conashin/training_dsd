module Clock_Div_50M (
    input wire i_Clock,     // 100 MHz clock
    output reg o_Clock = 0  // 50 MHz output
);
    reg toggle = 0;

    always @(posedge i_Clock) begin
        toggle <= ~toggle;  // �C��Ӯɯ��ܤ@��
        o_Clock <= toggle;
    end
endmodule
