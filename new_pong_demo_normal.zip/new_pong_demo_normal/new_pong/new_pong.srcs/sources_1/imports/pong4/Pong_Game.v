// Pong_Game (�w���� VGA ��ܼҲ� + �����p���P�C�q���)
module Pong_Game #(
    parameter       TOTAL_COL = 800,
    parameter       TOTAL_ROW = 525,
    parameter       ACTIVE_COL = 640,
    parameter       ACTIVE_ROW = 480
)(
    input           i_Clock,
    input           i_n_Reset,
    input           i_ps2d,
    input           i_ps2c,
    output          o_VSync,
    output          o_HSync,
    output [3:0]    o_Red,
    output [3:0]    o_Green,
    output [3:0]    o_Blue,
    output [6:0]    o_seg,
    output [3:0]    o_an
);

    wire w_Reset = ~i_n_Reset;
    
    parameter Paddle_Width  = 10;
    parameter Paddle_Length = 45;
    parameter Ball_Size     = 7;
    parameter Paddle_1_X_Pos = 40;
    parameter Paddle_1_Y_Pos = ACTIVE_ROW / 2;
    parameter Paddle_2_X_Pos = ACTIVE_COL - 1 - 40;
    parameter Paddle_2_Y_Pos = ACTIVE_ROW / 2;
    parameter Ball_X_Pos     = ACTIVE_COL / 2;
    parameter Ball_Y_Pos     = ACTIVE_ROW / 2;
    parameter Paddle_Speed  = 80000;
    parameter Ball_Speed    = 90000;
    parameter Pos_X_Max     = ACTIVE_COL - 1;
    parameter Pos_X_Min     = 0;
    parameter Pos_Y_Max     = ACTIVE_ROW - 1;
    parameter Pos_Y_Min     = 0;
    
    wire clk25;
    wire clk_locked;
    wire w_Clock_50MHz;
    clk_wiz_0 clkgen (.clk_in1(i_Clock), .clk_out1(clk25), .reset(w_Reset), .locked(clk_locked));
    Clock_Div_50M Clock_50MHz (.i_Clock(i_Clock), .o_Clock(w_Clock_50MHz));
    
    wire [7:0] scan_code;
    wire       rx_done_tick;
    wire       w_Space;
    wire [7:0] ascii_code;
    wire [3:0] w_Button, w_Button_2;
    
    ps2_rx ps2_rx_unit (.clk(w_Clock_50MHz), .reset(w_Reset), .rx_en(1'b1), .ps2d(i_ps2d), .ps2c(i_ps2c), .rx_done_tick(rx_done_tick), .rx_data(scan_code));
    key2ascii k2a_unit (.scan_code(scan_code), .ascii_code(ascii_code));
    Check_Key #(8'h61, 8'h64) A_D_KEYS (.i_Clock(w_Clock_50MHz), .i_ASCII_Code(ascii_code), .rx_done_tick(rx_done_tick), .o_Key1(w_Button[1]), .o_Key2(w_Button[0]), .o_Space(w_Space));
    Check_Key #(8'h77, 8'h73) W_S_KEYS (.i_Clock(w_Clock_50MHz), .i_ASCII_Code(ascii_code), .rx_done_tick(rx_done_tick), .o_Key1(w_Button[3]), .o_Key2(w_Button[2]), .o_Space());
    Check_Key #(8'h6A, 8'h6C) J_L_KEYS (.i_Clock(w_Clock_50MHz), .i_ASCII_Code(ascii_code), .rx_done_tick(rx_done_tick), .o_Key1(w_Button_2[1]), .o_Key2(w_Button_2[0]), .o_Space());
    Check_Key #(8'h69, 8'h6B) I_K_KEYS (.i_Clock(w_Clock_50MHz), .i_ASCII_Code(ascii_code), .rx_done_tick(rx_done_tick), .o_Key1(w_Button_2[3]), .o_Key2(w_Button_2[2]), .o_Space());
    
    wire [10:0] P_x, P_y, P_x_2, P_y_2, P_x_Ball, P_y_Ball;
    Paddle_Position #(.pos_MAX((ACTIVE_COL / 2) - 30), .pos_MIN(30), .origin(Paddle_1_X_Pos), .Paddle_Speed(Paddle_Speed)) Paddle_1_X (.i_Clock(clk25), .i_Reset(w_Reset), .i_Switch(w_Button[1:0]), .o_New_Pos(P_x));
    Paddle_Position #(.pos_MAX(ACTIVE_COL - 30), .pos_MIN((ACTIVE_COL / 2) + 30), .origin(Paddle_2_X_Pos), .Paddle_Speed(Paddle_Speed)) Paddle_2_X (.i_Clock(clk25), .i_Reset(w_Reset), .i_Switch(w_Button_2[1:0]), .o_New_Pos(P_x_2));
    Paddle_Position #(.pos_MAX(ACTIVE_ROW - 50), .pos_MIN(50), .origin(Paddle_1_Y_Pos), .Paddle_Speed(Paddle_Speed)) Paddle_1_Y (.i_Clock(clk25), .i_Reset(w_Reset), .i_Switch(w_Button[3:2]), .o_New_Pos(P_y));
    Paddle_Position #(.pos_MAX(ACTIVE_ROW - 50), .pos_MIN(50), .origin(Paddle_2_Y_Pos), .Paddle_Speed(Paddle_Speed)) Paddle_2_Y (.i_Clock(clk25), .i_Reset(w_Reset), .i_Switch(w_Button_2[3:2]), .o_New_Pos(P_y_2));
    Ball_Position #(Pos_X_Max, Pos_X_Min, Ball_X_Pos, Ball_Speed) Ball_X (.i_Clock(clk25), .i_Reset(w_Reset), .i_Paddle_Hit(Paddle_Hit), .i_Win(Win), .i_Space(w_Space), .o_Direction(w_Direction), .o_Pos(P_x_Ball));
    Ball_Position #(Pos_Y_Max, Pos_Y_Min, Ball_Y_Pos, Ball_Speed) Ball_Y (.i_Clock(clk25), .i_Reset(w_Reset), .i_Paddle_Hit(1'b0), .i_Win(Win), .i_Space(w_Space), .o_Direction(), .o_Pos(P_y_Ball));
    
    assign P1_Win = (P_x_Ball <= Pos_X_Min + Ball_Size);
    assign P2_Win = (P_x_Ball >= Pos_X_Max - Ball_Size);
    assign Win = (P1_Win || P2_Win);
    
    assign Paddle_1_Hit = (w_Direction == 1'b0) && (P_x_Ball - Ball_Size <= P_x + Paddle_Width) && (P_x_Ball - Ball_Size > P_x - Paddle_Width) && (P_y_Ball + Ball_Size >= P_y - Paddle_Length) && (P_y_Ball - Ball_Size <= P_y + Paddle_Length);
    assign Paddle_2_Hit = (w_Direction == 1'b1) && (P_x_Ball + Ball_Size >= P_x_2 - Paddle_Width) && (P_x_Ball + Ball_Size < P_x_2 + Paddle_Width) && (P_y_Ball + Ball_Size >= P_y_2 - Paddle_Length) && (P_y_Ball - Ball_Size <= P_y_2 + Paddle_Length);
    assign Paddle_Hit = (Paddle_1_Hit || Paddle_2_Hit);
    
    wire [3:0] score_left, score_right;
    pong_score_display score_display_unit (
        .clk(clk25),
        .reset(w_Reset),
        .p1_win(P1_Win),
        .p2_win(P2_Win),
        .score_left(score_left),
        .score_right(score_right),
        .o_seg(o_seg),
        .o_an(o_an)
    );
    
    pong_vga_display #(
        .ACTIVE_COL(ACTIVE_COL),
        .ACTIVE_ROW(ACTIVE_ROW),
        .TOTAL_COL(TOTAL_COL),
        .TOTAL_ROW(TOTAL_ROW),
        .Ball_Size(Ball_Size),
        .Paddle_Width(Paddle_Width),
        .Paddle_Length(Paddle_Length)
    ) vga_display_unit (
        .clk(clk25),
        .reset(w_Reset),
        .P_x(P_x),
        .P_y(P_y),
        .P_x_2(P_x_2),
        .P_y_2(P_y_2),
        .P_x_Ball(P_x_Ball),
        .P_y_Ball(P_y_Ball),
        .o_HSync(o_HSync),
        .o_VSync(o_VSync),
        .o_Red(o_Red),
        .o_Green(o_Green),
        .o_Blue(o_Blue)
    );

endmodule
