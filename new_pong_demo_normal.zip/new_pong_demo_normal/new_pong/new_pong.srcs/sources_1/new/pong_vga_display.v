module pong_vga_display #(
    parameter ACTIVE_COL = 640,
    parameter ACTIVE_ROW = 480,
    parameter TOTAL_COL = 800,
    parameter TOTAL_ROW = 525,
    parameter Ball_Size = 7,
    parameter Paddle_Width = 10,
    parameter Paddle_Length = 45
)(
    input wire clk,
    input wire reset,
    input wire [10:0] P_x, P_y,
    input wire [10:0] P_x_2, P_y_2,
    input wire [10:0] P_x_Ball, P_y_Ball,
    output wire [3:0] o_Red,
    output wire [3:0] o_Green,
    output wire [3:0] o_Blue,
    output wire o_HSync,
    output wire o_VSync
);

    // VGA Timing �p�ƾ�
    reg [10:0] h_count = 0, v_count = 0;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            h_count <= 0;
            v_count <= 0;
        end else begin
            if (h_count == TOTAL_COL - 1) begin
                h_count <= 0;
                if (v_count == TOTAL_ROW - 1)
                    v_count <= 0;
                else
                    v_count <= v_count + 1;
            end else begin
                h_count <= h_count + 1;
            end
        end
    end

    assign o_HSync = (h_count < ACTIVE_COL + (TOTAL_COL - ACTIVE_COL - 96 - 48)) ||
                     (h_count >= (ACTIVE_COL + (TOTAL_COL - ACTIVE_COL - 96 - 48) + 96));
    assign o_VSync = (v_count < ACTIVE_ROW + (TOTAL_ROW - ACTIVE_ROW - 2 - 33)) ||
                     (v_count >= (ACTIVE_ROW + (TOTAL_ROW - ACTIVE_ROW - 2 - 33) + 2));

    wire video_on = (h_count < ACTIVE_COL) && (v_count < ACTIVE_ROW);
    wire [10:0] pixel_x = h_count;
    wire [10:0] pixel_y = v_count;

    // ��ܱ���
    wire Ball_En = (pixel_x >= (P_x_Ball - Ball_Size)) && (pixel_x <= (P_x_Ball + Ball_Size)) &&
                   (pixel_y >= (P_y_Ball - Ball_Size)) && (pixel_y <= (P_y_Ball + Ball_Size));

    wire Paddle_1_En = (pixel_x >= (P_x - Paddle_Width)) && (pixel_x <= (P_x + Paddle_Width)) &&
                       (pixel_y >= (P_y - Paddle_Length)) && (pixel_y <= (P_y + Paddle_Length));

    wire Paddle_2_En = (pixel_x >= (P_x_2 - Paddle_Width)) && (pixel_x <= (P_x_2 + Paddle_Width)) &&
                       (pixel_y >= (P_y_2 - Paddle_Length)) && (pixel_y <= (P_y_2 + Paddle_Length));

    wire mid_line_en = (pixel_x >= (ACTIVE_COL / 2 - 1)) && (pixel_x <= (ACTIVE_COL / 2 + 1)) && (pixel_y[3] == 1'b0);
    wire top_bottom_en = (pixel_y <= 4 || pixel_y >= (ACTIVE_ROW - 5));
    wire left_right_en = (pixel_x <= 4 || pixel_x >= (ACTIVE_COL - 5));
    wire is_object_pixel = Paddle_1_En || Paddle_2_En || Ball_En;

    assign o_Red = (video_on && is_object_pixel) ? 4'hF :
                   (video_on && left_right_en)   ? 4'hF :
                   (video_on && mid_line_en)     ? 4'hF : 4'h0;

    assign o_Green = (video_on && is_object_pixel) ? 4'hF :
                     (video_on && top_bottom_en)   ? 4'hF :
                     (video_on && mid_line_en)     ? 4'hF : 4'h0;

    assign o_Blue = (video_on && is_object_pixel) ? 4'hF : 4'h0;

endmodule
