// === �����᪺�p���P�C�q��ܼҲ� ===
module pong_score_display(
    input wire clk,
    input wire reset,
    input wire p1_win,
    input wire p2_win,
    output reg [3:0] score_left,
    output reg [3:0] score_right,
    output wire [6:0] o_seg,
    output wire [3:0] o_an
);

    // �W�tĲ�o����
    reg p1_win_d = 0, p2_win_d = 0;
    wire p1_score = p1_win && ~p1_win_d;
    wire p2_score = p2_win && ~p2_win_d;

    // ���ưO��
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            score_left <= 0;
            score_right <= 0;
            p1_win_d <= 0;
            p2_win_d <= 0;
        end else begin
            p1_win_d <= p1_win;
            p2_win_d <= p2_win;
            if (p1_score && score_left < 9) score_left <= score_left + 1;
            if (p2_score && score_right < 9) score_right <= score_right + 1;
        end
    end

    // ���y����
    reg [16:0] scan_cnt = 0;
    reg [1:0] scan_pos = 0;
    reg [3:0] digit;
    reg [6:0] seg;

    always @(posedge clk) begin
        scan_cnt <= scan_cnt + 1;
        if (scan_cnt >= 100000) begin
            scan_cnt <= 0;
            scan_pos <= scan_pos + 1;
        end
    end

    // ���y��ܸ��
    always @(*) begin
        case (scan_pos)
            2'd0: digit = 4'd15;        // �ť�
            2'd1: digit = score_right;  // �k�䪱�a����
            2'd2: digit = 4'd10;        // �������j '-'
            2'd3: digit = score_left;   // ���䪱�a����
        endcase
    end

    // �C�q�r��
    always @(*) begin
        case (digit)
            4'd0:  seg = 7'b0111111;
            4'd1:  seg = 7'b0000110;
            4'd2:  seg = 7'b1011011;
            4'd3:  seg = 7'b1001111;
            4'd4:  seg = 7'b1100110;
            4'd5:  seg = 7'b1101101;
            4'd6:  seg = 7'b1111101;
            4'd7:  seg = 7'b0000111;
            4'd8:  seg = 7'b1111111;
            4'd9:  seg = 7'b1101111;
            4'd10: seg = 7'b1000000; // '-'
            default: seg = 7'b0000000;
        endcase
    end

    assign o_seg = seg;
    assign o_an = (scan_pos == 2'd0) ? 4'b0000 :
                  (scan_pos == 2'd1) ? 4'b0010 :
                  (scan_pos == 2'd2) ? 4'b0100 :
                                       4'b1000;

endmodule
