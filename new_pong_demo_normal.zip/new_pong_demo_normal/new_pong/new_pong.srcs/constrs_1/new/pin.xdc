## Clock Input (100 MHz)
set_property PACKAGE_PIN P17 [get_ports i_Clock]
set_property IOSTANDARD LVCMOS33 [get_ports i_Clock]

## Reset Button (S6, active low)
set_property PACKAGE_PIN P15 [get_ports i_n_Reset]
set_property IOSTANDARD LVCMOS33 [get_ports i_n_Reset]

## PS/2 Keyboard
set_property PACKAGE_PIN K5 [get_ports i_ps2c]
set_property IOSTANDARD LVCMOS33 [get_ports i_ps2c]
set_property PACKAGE_PIN L4 [get_ports i_ps2d]
set_property IOSTANDARD LVCMOS33 [get_ports i_ps2d]

## VGA Sync
set_property PACKAGE_PIN D7 [get_ports o_HSync]
set_property PACKAGE_PIN C4 [get_ports o_VSync]
set_property IOSTANDARD LVCMOS33 [get_ports o_HSync]
set_property IOSTANDARD LVCMOS33 [get_ports o_VSync]

## VGA Red [3:0]
set_property PACKAGE_PIN F5 [get_ports {o_Red[0]}]
set_property PACKAGE_PIN C6 [get_ports {o_Red[1]}]
set_property PACKAGE_PIN C5 [get_ports {o_Red[2]}]
set_property PACKAGE_PIN B7 [get_ports {o_Red[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {o_Red[*]}]

## VGA Green [3:0]
set_property PACKAGE_PIN B6 [get_ports {o_Green[0]}]
set_property PACKAGE_PIN A6 [get_ports {o_Green[1]}]
set_property PACKAGE_PIN A5 [get_ports {o_Green[2]}]
set_property PACKAGE_PIN D8 [get_ports {o_Green[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {o_Green[*]}]

## VGA Blue [3:0]
set_property PACKAGE_PIN C7 [get_ports {o_Blue[0]}]
set_property PACKAGE_PIN E6 [get_ports {o_Blue[1]}]
set_property PACKAGE_PIN E5 [get_ports {o_Blue[2]}]
set_property PACKAGE_PIN E7 [get_ports {o_Blue[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {o_Blue[*]}]

## 7-segment Display (Common Anode)
# Segment [6:0]
set_property PACKAGE_PIN B4 [get_ports {o_seg[0]}]
set_property PACKAGE_PIN A4 [get_ports {o_seg[1]}]
set_property PACKAGE_PIN A3 [get_ports {o_seg[2]}]
set_property PACKAGE_PIN B1 [get_ports {o_seg[3]}]
set_property PACKAGE_PIN A1 [get_ports {o_seg[4]}]
set_property PACKAGE_PIN B3 [get_ports {o_seg[5]}]
set_property PACKAGE_PIN B2 [get_ports {o_seg[6]}]
set_property IOSTANDARD LVCMOS33 [get_ports {o_seg[*]}]

# Anode [3:0]
set_property PACKAGE_PIN H1 [get_ports {o_an[3]}]
set_property PACKAGE_PIN C1 [get_ports {o_an[2]}]
set_property PACKAGE_PIN C2 [get_ports {o_an[1]}]
set_property PACKAGE_PIN G2 [get_ports {o_an[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {o_an[*]}]
