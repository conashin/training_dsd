import os
import pygame
import random

class TetrisEffects:
    def __init__(self,
                 bgm_normal="assets/bgm.mp3",
                 bgm_faster="assets/bgm_fast.mp3",
                 bgm_fastest="assets/bgm_faster.mp3",
                 clear1_path="assets/clear.wav",
                 clear2_path="assets/good_clear.wav",
                 clear4_path="assets/best_clear.wav",
                 flash_img_path="assets/clear_flash.jpg",
                 death_path="assets/death.wav",
                 death_img_path="assets/death_sceen.jpg"):
        pygame.mixer.init()
        pygame.mixer.set_num_channels(8)
        self.effect_channel = pygame.mixer.Channel(1)

        self.bgm_paths = {
            "normal": bgm_normal,
            "faster": bgm_faster,
            "fastest": bgm_fastest
        }
        self.current_bgm = "normal"

        try:
            self.clear1 = pygame.mixer.Sound(clear1_path)
            self.clear2 = pygame.mixer.Sound(clear2_path)
            self.clear4 = pygame.mixer.Sound(clear4_path)
            for sound in [self.clear1, self.clear2, self.clear4]:
                sound.set_volume(1.0)
        except pygame.error as e:
            print("Error loading sound effects:", e)

        try:
            self.death_sound = pygame.mixer.Sound(death_path)
            self.death_sound.set_volume(1.0)
        except pygame.error as e:
            print("Error loading death sound:", e)

        self.flash_image = None
        if os.path.exists(flash_img_path):
            try:
                self.flash_image = pygame.image.load(flash_img_path)
                self.flash_image = pygame.transform.scale(self.flash_image, (300, 600))
            except Exception as e:
                print("Error loading flash image:", e)

        self.death_image = None
        if os.path.exists(death_img_path):
            try:
                self.death_image = pygame.image.load(death_img_path)
                self.death_image = pygame.transform.scale(self.death_image, (300, 600))
            except Exception as e:
                print("Error loading death image:", e)

        self.bag = list(range(7))
        random.shuffle(self.bag)

    def play_bgm(self, level="normal"):
        try:
            if level != self.current_bgm:
                pygame.mixer.music.stop()
                pygame.mixer.music.load(self.bgm_paths[level])
                pygame.mixer.music.set_volume(0.5)
                pygame.mixer.music.play(-1)
                self.current_bgm = level
            elif not pygame.mixer.music.get_busy():
                pygame.mixer.music.load(self.bgm_paths[level])
                pygame.mixer.music.set_volume(0.5)
                pygame.mixer.music.play(-1)
        except Exception as e:
            print("Error playing BGM:", e)

    def pause_bgm(self):
        pygame.mixer.music.pause()

    def resume_bgm(self):
        pygame.mixer.music.unpause()

    def play_clear_effect(self, screen, draw_func, grid, level, score, lines,
                          next_piece, hold_piece, current_piece, cleared):
        sound = None
        if cleared == 1 and hasattr(self, 'clear1'):
            sound = self.clear1
        elif cleared in [2, 3] and hasattr(self, 'clear2'):
            sound = self.clear2
        elif cleared >= 4 and hasattr(self, 'clear4'):
            sound = self.clear4

        total_delay = 0

        if sound:
            self.effect_channel.play(sound)

        if cleared >= 4:
            try:
                for _ in range(2):
                    draw_func(screen, grid, level, score, lines,
                              next_piece, hold_piece, current_piece)
                    pygame.display.update()
                    pygame.time.delay(100)
                    total_delay += 100
                    screen.fill((0, 0, 0))
                    pygame.display.update()
                    pygame.time.delay(100)
                    total_delay += 100

                if self.flash_image:
                    screen.blit(self.flash_image, (0, 0))
                    pygame.display.update()
                    pygame.time.delay(300)
                    total_delay += 300
            except Exception as e:
                print("Animation Error:", e)

        if total_delay < 1000:
            pygame.time.delay(1000 - total_delay)

    def play_death_effect(self, screen):
        self.pause_bgm()
        try:
            self.death_sound.play()
            sound_len = int(self.death_sound.get_length() * 1000)
            if self.death_image:
                screen.blit(self.death_image, (0, 0))
                pygame.display.update()
            pygame.time.delay(sound_len)
        except Exception as e:
            print("Error during death effect:", e)
        finally:
            self.resume_bgm()

    def get_next_shape_index(self):
        if not self.bag:
            self.bag = list(range(7))
            random.shuffle(self.bag)
        return self.bag.pop()
