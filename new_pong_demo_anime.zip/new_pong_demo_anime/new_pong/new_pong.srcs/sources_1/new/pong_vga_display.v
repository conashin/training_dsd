module pong_vga_display #(
    parameter ACTIVE_COL = 640,
    parameter ACTIVE_ROW = 480,
    parameter TOTAL_COL  = 800,
    parameter TOTAL_ROW  = 525,
    parameter Ball_Size = 7,
    parameter Paddle_Width = 10,
    parameter Paddle_Length = 45
)(
    input wire clk,
    input wire reset,
    input wire [10:0] P_x, P_y,
    input wire [10:0] P_x_2, P_y_2,
    input wire [10:0] P_x_Ball, P_y_Ball,
    output wire o_HSync,
    output wire o_VSync,
    output reg [3:0] o_Red,
    output reg [3:0] o_Green,
    output reg [3:0] o_Blue
);

    // === VGA Timing ===
    reg [10:0] h_count = 0;
    reg [9:0]  v_count = 0;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            h_count <= 0;
            v_count <= 0;
        end else begin
            if (h_count == TOTAL_COL - 1) begin
                h_count <= 0;
                v_count <= (v_count == TOTAL_ROW - 1) ? 0 : v_count + 1;
            end else begin
                h_count <= h_count + 1;
            end
        end
    end

    assign o_HSync = ~(h_count >= ACTIVE_COL + 16 && h_count < ACTIVE_COL + 16 + 96);
    assign o_VSync = ~(v_count >= ACTIVE_ROW + 10 && v_count < ACTIVE_ROW + 10 + 2);

    wire visible = (h_count < ACTIVE_COL) && (v_count < ACTIVE_ROW);

    // === �I���ʵe��� ===
    wire [3:0] bg_r, bg_g, bg_b;
    vga_anim_display bg (
        .clk(clk),
        .reset(reset),
        .h_cnt(h_count),
        .v_cnt(v_count),
        .r(bg_r),
        .g(bg_g),
        .b(bg_b)
    );

    // === �e������P�_ ===
    parameter BORDER_THICKNESS = 5;
    parameter MIDDLE_LINE_WIDTH = 3;     // ���u�e��
    wire is_paddle_1 = (h_count >= P_x - Paddle_Width && h_count <= P_x + Paddle_Width &&
                        v_count >= P_y - Paddle_Length && v_count <= P_y + Paddle_Length);
    wire is_paddle_2 = (h_count >= P_x_2 - Paddle_Width && h_count <= P_x_2 + Paddle_Width &&
                        v_count >= P_y_2 - Paddle_Length && v_count <= P_y_2 + Paddle_Length);
    wire is_ball = (h_count >= P_x_Ball - Ball_Size && h_count <= P_x_Ball + Ball_Size &&
                    v_count >= P_y_Ball - Ball_Size && v_count <= P_y_Ball + Ball_Size);

    // ���u�d���X�i���e�ס]���^
    wire is_middle_line = (h_count >= (ACTIVE_COL / 2 - MIDDLE_LINE_WIDTH/2)) &&
                          (h_count <= (ACTIVE_COL / 2 + MIDDLE_LINE_WIDTH/2)) &&
                          (v_count % 20 < 10);

    wire is_top_border    = (v_count < BORDER_THICKNESS);
    wire is_bottom_border = (v_count >= ACTIVE_ROW - BORDER_THICKNESS);
    wire is_left_border   = (h_count < BORDER_THICKNESS);
    wire is_right_border  = (h_count >= ACTIVE_COL - BORDER_THICKNESS);

    // === ����C��M�w ===
       always @(*) begin
        if (!visible) begin
            {o_Red, o_Green, o_Blue} = 12'h000;
        end else if (is_ball || is_paddle_1 || is_paddle_2) begin
            {o_Red, o_Green, o_Blue} = 12'hFFF;  // �զ⪫��
        end else if (is_top_border || is_bottom_border) begin
            {o_Red, o_Green, o_Blue} = 12'h0F0;  // ���W�U���
        end else if (is_left_border || is_right_border) begin
            {o_Red, o_Green, o_Blue} = 12'hF00;  // ���⥪�k���
        end else if (is_middle_line) begin
            {o_Red, o_Green, o_Blue} = 12'hFF0;  // ���⤤�u
        end else begin
            {o_Red, o_Green, o_Blue} = {bg_r, bg_g, bg_b}; // �I���ʵe
        end
      end


endmodule
