module vga_anim_display (
    input wire clk,
    input wire reset,
    input wire [10:0] h_cnt,
    input wire [9:0]  v_cnt,
    output wire [3:0] r,
    output wire [3:0] g,
    output wire [3:0] b
);

    parameter SCALE = 3;  
    parameter FRAME_WIDTH  = 160;
    parameter FRAME_HEIGHT = 120;
    parameter FRAME_COUNT  = 6;
    parameter PIXELS_PER_FRAME = FRAME_WIDTH * FRAME_HEIGHT;
    parameter FRAME_DURATION = 1_000_000;  // 1 frame ? 1/30 �� @ 30 MHz

    localparam SCALED_WIDTH  = FRAME_WIDTH * SCALE;
    localparam SCALED_HEIGHT = FRAME_HEIGHT * SCALE;
    localparam CENTER_X = (640 - SCALED_WIDTH) / 2;
    localparam CENTER_Y = (480 - SCALED_HEIGHT) / 2;

    // ========================
    // �ʵe Frame �p�ƾ�
    // ========================
    reg [19:0] frame_tick_counter = 0;
    reg [3:0]  current_frame = 0;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            frame_tick_counter <= 0;
            current_frame <= 0;
        end else if (frame_tick_counter == FRAME_DURATION - 1) begin
            frame_tick_counter <= 0;
            current_frame <= (current_frame == FRAME_COUNT - 1) ? 0 : current_frame + 1;
        end else begin
            frame_tick_counter <= frame_tick_counter + 1;
        end
    end

    // ========================
    // ��j����޿�]�~����ܡ^
    // ========================
    wire show_anim = (h_cnt >= CENTER_X && h_cnt < CENTER_X + SCALED_WIDTH &&
                      v_cnt >= CENTER_Y && v_cnt < CENTER_Y + SCALED_HEIGHT);

    wire [7:0] anim_x = show_anim ? ((h_cnt - CENTER_X) / SCALE) : 8'd0;
    wire [6:0] anim_y = show_anim ? ((v_cnt - CENTER_Y) / SCALE) : 7'd0;

    wire [18:0] rom_addr = show_anim ?
        (current_frame * PIXELS_PER_FRAME + anim_y * FRAME_WIDTH + anim_x) : 19'd0;

    wire [11:0] pixel_data;

    anim_rom rom (
        .clka(clk),
        .addra(rom_addr),
        .douta(pixel_data)
    );

    // ========================
    // �b�z�����
    // ========================
    wire [3:0] r_half = pixel_data[11:8] >> 1;
    wire [3:0] g_half = pixel_data[7:4]  >> 1;
    wire [3:0] b_half = pixel_data[3:0]  >> 1;

    assign r = show_anim ? r_half : 4'd0;
    assign g = show_anim ? g_half : 4'd0;
    assign b = show_anim ? b_half : 4'd0;

endmodule
