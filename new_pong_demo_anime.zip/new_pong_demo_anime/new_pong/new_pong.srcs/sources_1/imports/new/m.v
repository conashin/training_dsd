module top_anim_display (
    input wire clk,       // 100 MHz input clock
    input wire reset,     // active LOW reset
    output wire hsync,
    output wire vsync,
    output wire [3:0] vga_r,
    output wire [3:0] vga_g,
    output wire [3:0] vga_b
);

    // ===============================
    // Clock divider: 100MHz �� 30MHz
    // ===============================
    wire clk_30m;
    wire clk_locked;
    wire rst = ~reset;  // ? Active-HIGH reset

    clk_wiz_30 clkgen (
        .clk_in1(clk),
        .reset(rst),
        .clk_out1(clk_30m),
        .locked(clk_locked)
    );

    // ===============================
    // VGA timing generator
    // ===============================
    reg [10:0] h_count = 0;
    reg [9:0]  v_count = 0;

    localparam H_VISIBLE = 640, H_FRONT = 16, H_SYNC = 96, H_BACK = 48, H_TOTAL = 800;
    localparam V_VISIBLE = 480, V_FRONT = 10, V_SYNC = 2, V_BACK = 33, V_TOTAL = 525;

    always @(posedge clk_30m or posedge rst) begin
        if (rst) begin
            h_count <= 0;
            v_count <= 0;
        end else begin
            if (h_count == H_TOTAL - 1) begin
                h_count <= 0;
                v_count <= (v_count == V_TOTAL - 1) ? 0 : v_count + 1;
            end else begin
                h_count <= h_count + 1;
            end
        end
    end

    assign hsync = ~(h_count >= H_VISIBLE + H_FRONT && h_count < H_VISIBLE + H_FRONT + H_SYNC);
    assign vsync = ~(v_count >= V_VISIBLE + V_FRONT && v_count < V_VISIBLE + V_FRONT + V_SYNC);

    // ===============================
    // �ʵe��ܼҲ�
    // ===============================
    wire [3:0] anim_r, anim_g, anim_b;

    vga_anim_display bg_anim (
        .clk(clk_30m),
        .reset(rst),
        .h_cnt(h_count),
        .v_cnt(v_count),
        .r(anim_r),
        .g(anim_g),
        .b(anim_b)
    );

    wire display_area = (h_count < H_VISIBLE) && (v_count < V_VISIBLE);
    assign vga_r = display_area ? anim_r : 4'd0;
    assign vga_g = display_area ? anim_g : 4'd0;
    assign vga_b = display_area ? anim_b : 4'd0;

endmodule
