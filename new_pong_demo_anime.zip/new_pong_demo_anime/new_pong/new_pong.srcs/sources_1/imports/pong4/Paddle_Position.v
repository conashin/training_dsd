module Paddle_Position
#( 
    parameter pos_MAX = 0,
    parameter pos_MIN = 0,
    parameter origin  = 0,
    parameter Paddle_Speed = 0
)
(
    input         i_Clock,
    input         i_Reset,
    input  [1:0]  i_Switch,       // [0]: ?V?k?F[1]: ?V??
    output [10:0] o_New_Pos
);

reg  [31:0] r_Count;
reg  [10:0] r_Pos;
wire        w_Right =  i_Switch[0] & ~i_Switch[1]; // ????k
wire        w_Left  = ~i_Switch[0] &  i_Switch[1]; // ?????

always @(posedge i_Clock or posedge i_Reset) begin
    if (i_Reset) begin
        r_Pos   <= origin;
        r_Count <= 0;
    end
    else if (w_Right) begin
        if (r_Pos < pos_MAX) begin
            if (r_Count == 0) begin
                r_Pos   <= r_Pos + 1;
                r_Count <= Paddle_Speed;
            end else begin
                r_Count <= r_Count - 1;
            end
        end else begin
            r_Count <= 0;  // ????k?s
        end
    end
    else if (w_Left) begin
        if (r_Pos > pos_MIN) begin
            if (r_Count == 0) begin
                r_Pos   <= r_Pos - 1;
                r_Count <= Paddle_Speed;
            end else begin
                r_Count <= r_Count - 1;
            end
        end else begin
            r_Count <= 0;  // ????k?s
        end
    end
    else begin
        r_Count <= 0;  // ?S????V??J?�XP????G?M??
    end
end

assign o_New_Pos = r_Pos;

endmodule
